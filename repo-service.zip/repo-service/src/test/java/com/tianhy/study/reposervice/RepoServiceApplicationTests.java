package com.tianhy.study.reposervice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RepoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
